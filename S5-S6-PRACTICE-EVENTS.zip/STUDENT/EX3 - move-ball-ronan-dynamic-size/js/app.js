const BALL_SIZE = 100;

let ball = document.getElementById("ball");
let ballArea = document.getElementById("ball-area");
let box = document.querySelector("#boxId");

function moveLeft() {
	// Move the box left
};

function moveRight() {
	// Move the box right
};

function moveUp() {
	// Move the box up
};

function moveDown() {
  // Move the box down
};

// Get the 4 buttons and bind to the 4 functions
