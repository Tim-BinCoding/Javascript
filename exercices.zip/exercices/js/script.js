// Function 1 (as example)
function function1(num1, num2) {
  return (num1 + num2) / 2;
}
console.log("test function1:", function1(4, 6));

// Function 2 (as example)
// TODO
console.log("test function2:");

// Function 3 (as example)
// TODO
console.log("test function3:");

// Function 4 (as example)
// TODO
console.log("test function4:");

// Function 5 (as example)
// TODO
console.log("test function5:");

// Function 6 (as example)
// TODO
console.log("test function6:");

// Function 7 (as example)
// TODO
console.log("test function7:");

// Function 8 (as example)
// TODO
console.log("test function8:");
